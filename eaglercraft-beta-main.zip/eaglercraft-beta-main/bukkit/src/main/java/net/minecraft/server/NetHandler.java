package net.minecraft.server;

import net.lax1dude.eaglercraft.beta.server.Packet69EaglercraftData;

public class NetHandler {
	public void a(Packet51MapChunk var1) {
	}

	public void a(Packet var1) {
	}

	public void a(String var1, Object[] var2) {
	}

	public void a(Packet255KickDisconnect var1) {
		this.a((Packet) var1);
	}

	public void a(Packet1Login var1) {
		this.a((Packet) var1);
	}

	public void a(Packet10Flying var1) {
		this.a((Packet) var1);
	}

	public void a(Packet52MultiBlockChange var1) {
		this.a((Packet) var1);
	}

	public void a(Packet14BlockDig var1) {
		this.a((Packet) var1);
	}

	public void a(Packet53BlockChange var1) {
		this.a((Packet) var1);
	}

	public void a(Packet50PreChunk var1) {
		this.a((Packet) var1);
	}

	public void a(Packet20NamedEntitySpawn var1) {
		this.a((Packet) var1);
	}

	public void a(Packet30Entity var1) {
		this.a((Packet) var1);
	}

	public void a(Packet34EntityTeleport var1) {
		this.a((Packet) var1);
	}

	public void a(Packet15Place var1) {
		this.a((Packet) var1);
	}

	public void a(Packet16BlockItemSwitch var1) {
		this.a((Packet) var1);
	}

	public void a(Packet29DestroyEntity var1) {
		this.a((Packet) var1);
	}

	public void a(Packet21PickupSpawn var1) {
		this.a((Packet) var1);
	}

	public void a(Packet22Collect var1) {
		this.a((Packet) var1);
	}

	public void a(Packet3Chat var1) {
		this.a((Packet) var1);
	}

	public void a(Packet23VehicleSpawn var1) {
		this.a((Packet) var1);
	}

	public void a(Packet18ArmAnimation var1) {
		this.a((Packet) var1);
	}

	public void a(Packet19EntityAction var1) {
		this.a((Packet) var1);
	}

	public void a(Packet2Handshake var1) {
		this.a((Packet) var1);
	}

	public void a(Packet24MobSpawn var1) {
		this.a((Packet) var1);
	}

	public void a(Packet4UpdateTime var1) {
		this.a((Packet) var1);
	}

	public void a(Packet6SpawnPosition var1) {
		this.a((Packet) var1);
	}

	public void a(Packet28EntityVelocity var1) {
		this.a((Packet) var1);
	}

	public void a(Packet40EntityMetadata var1) {
		this.a((Packet) var1);
	}

	public void a(Packet39AttachEntity var1) {
		this.a((Packet) var1);
	}

	public void a(Packet7UseEntity var1) {
		this.a((Packet) var1);
	}

	public void a(Packet38EntityStatus var1) {
		this.a((Packet) var1);
	}

	public void a(Packet8UpdateHealth var1) {
		this.a((Packet) var1);
	}

	public void a(Packet9Respawn var1) {
		this.a((Packet) var1);
	}

	public void a(Packet60Explosion var1) {
		this.a((Packet) var1);
	}

	public void a(Packet100OpenWindow var1) {
		this.a((Packet) var1);
	}

	public void a(Packet101CloseWindow var1) {
		this.a((Packet) var1);
	}

	public void a(Packet102WindowClick var1) {
		this.a((Packet) var1);
	}

	public void a(Packet103SetSlot var1) {
		this.a((Packet) var1);
	}

	public void a(Packet104WindowItems var1) {
		this.a((Packet) var1);
	}

	public void a(Packet130UpdateSign var1) {
		this.a((Packet) var1);
	}

	public void a(Packet105CraftProgressBar var1) {
		this.a((Packet) var1);
	}

	public void a(Packet5EntityEquipment var1) {
		this.a((Packet) var1);
	}

	public void a(Packet106Transaction var1) {
		this.a((Packet) var1);
	}

	public void a(Packet25EntityPainting var1) {
		this.a((Packet) var1);
	}

	public void a(Packet54PlayNoteBlock var1) {
		this.a((Packet) var1);
	}

	public void a(Packet69EaglercraftData var1) {
		this.a((Packet) var1);
	}

	public void a(Packet17 var1) {
	}

	public void a(Packet27 var1) {
	}
}