package net.lax1dude.eaglercraft;

import net.lax1dude.eaglercraft.glemu.EaglerAdapterGL30;

public class EaglerAdapter extends EaglerAdapterGL30 {

}