package net.minecraft.src;

import net.lax1dude.eaglercraft.EaglerImage;

// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.

// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

public interface ImageBuffer {

	public abstract EaglerImage parseUserSkin(EaglerImage bufferedimage);
}
